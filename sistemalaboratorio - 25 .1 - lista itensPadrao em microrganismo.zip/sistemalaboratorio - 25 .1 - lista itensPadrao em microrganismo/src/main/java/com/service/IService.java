package com.service;



public interface IService {
	
}