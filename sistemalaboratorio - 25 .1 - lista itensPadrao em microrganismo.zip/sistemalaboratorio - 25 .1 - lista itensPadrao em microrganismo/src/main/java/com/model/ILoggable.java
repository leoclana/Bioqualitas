package com.model;

public interface ILoggable {

	String getIdentifier();
	
}
