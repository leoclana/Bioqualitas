package com.dao;

import com.model.Laudo;

/**
 * Created by LeoLana on 10/04/2016.
 */
public interface ILaudoDao {

    public Laudo laudoById(Integer id);

}
